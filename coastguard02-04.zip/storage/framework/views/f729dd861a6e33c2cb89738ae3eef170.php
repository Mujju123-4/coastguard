<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-4xl mx-auto pb-12">
        <!-- Breadcrumb / Header -->
        <div class="mb-8 flex items-center justify-between">
            <div>
                <a href="<?php echo e(route('tickets.index')); ?>" class="inline-flex items-center text-slate-400 hover:text-orange-500 transition-colors text-sm font-medium mb-4 group">
                    <svg class="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                    Back to Tickets
                </a>
                <h2 class="text-2xl font-bold text-slate-800 tracking-tight">Ticket #<?php echo e(str_pad($ticket->id, 5, '0', STR_PAD_LEFT)); ?></h2>
                <div class="flex items-center gap-3 mt-2">
                    <span class="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase border 
                        <?php echo e($ticket->status === 'pending' ? 'bg-amber-100 text-amber-700 border-amber-200' : ''); ?>

                        <?php echo e($ticket->status === 'replied' ? 'bg-teal-100 text-teal-700 border-teal-200' : ''); ?>

                        <?php echo e($ticket->status === 'resolved' ? 'bg-emerald-100 text-emerald-700 border-emerald-200' : ''); ?>

                        <?php echo e($ticket->status === 'closed' ? 'bg-slate-100 text-slate-700 border-slate-200' : ''); ?>

                    ">
                        <?php echo e($ticket->status); ?>

                    </span>
                    <span class="text-slate-400 text-xs font-medium">Raised on <?php echo e($ticket->created_at->format('d M Y, h:i A')); ?></span>
                </div>
            </div>
            
            <div class="text-right hidden sm:block">
                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Assigned Unit</p>
                <p class="text-sm font-bold text-slate-700"><?php echo e($ticket->item->location->name ?? 'Global'); ?></p>
            </div>
        </div>

        <div class="space-y-6">
            <!-- Ticket Info Card -->
            <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
                <div class="px-8 py-6 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
                    <div class="flex items-center gap-4">
                        <div class="h-10 w-10 rounded-full bg-slate-800 flex items-center justify-center text-white font-bold">
                            <?php echo e(substr($ticket->user->name, 0, 1)); ?>

                        </div>
                        <div>
                            <p class="text-sm font-bold text-slate-800"><?php echo e($ticket->user->name); ?></p>
                            <p class="text-xs text-slate-400"><?php echo e($ticket->user->email); ?></p>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Item Reference</p>
                        <p class="text-sm font-black text-rose-600"><?php echo e($ticket->item->code); ?></p>
                    </div>
                </div>
                <div class="p-8">
                    <h3 class="text-lg font-bold text-slate-800 mb-4"><?php echo e($ticket->title); ?></h3>
                    <div class="bg-slate-50 rounded-lg p-6 border border-slate-100 italic text-slate-600 leading-relaxed text-sm">
                        "<?php echo e($ticket->description); ?>"
                    </div>
                </div>
            </div>

            <!-- Admin Response Section -->
            <?php if($ticket->admin_response): ?>
            <div class="bg-teal-50 rounded-xl shadow-sm border border-teal-100 overflow-hidden relative">
                <div class="absolute top-0 left-0 w-1 h-full bg-teal-500"></div>
                <div class="p-8">
                    <div class="flex items-center justify-between mb-4">
                        <div class="flex items-center gap-3">
                            <div class="h-8 w-8 rounded-lg bg-teal-600 flex items-center justify-center text-white">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                            </div>
                            <span class="text-sm font-bold text-teal-900 tracking-tight">Admin Official Response</span>
                        </div>
                        <span class="text-xs font-medium text-teal-600/60 tracking-tighter">Replied on <?php echo e($ticket->replied_at ? $ticket->replied_at->format('d M Y, h:i A') : 'N/A'); ?></span>
                    </div>
                    <div class="text-teal-900/80 leading-relaxed text-sm font-medium">
                        <?php echo nl2br(e($ticket->admin_response)); ?>

                    </div>
                </div>
            </div>
            <?php endif; ?>

            <!-- Admin Reply Form -->
            <?php if(auth()->user()->hasRole('Admin') && $ticket->status !== 'closed'): ?>
            <div class="bg-white rounded-xl shadow-lg border border-slate-200 overflow-hidden mt-8">
                <div class="px-8 py-4 bg-slate-900 flex items-center justify-between">
                    <span class="text-white text-xs font-bold uppercase tracking-widest">Post Response</span>
                </div>
                <form action="<?php echo e(route('tickets.update', $ticket->id)); ?>" method="POST" class="p-8 space-y-6">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    
                    <div>
                        <label for="admin_response" class="block text-[11px] font-bold text-slate-400 uppercase tracking-widest mb-3">Your Answer</label>
                        <textarea name="admin_response" id="admin_response" rows="4" placeholder="Type your response to the user here..." class="w-full bg-slate-50 border border-slate-200 text-slate-600 px-4 py-3 rounded-lg focus:ring-2 focus:ring-teal-500/20 focus:border-teal-500 outline-none transition-all text-sm min-h-[100px] <?php $__errorArgs = ['admin_response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('admin_response', $ticket->admin_response)); ?></textarea>
                        <?php $__errorArgs = ['admin_response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="text-red-500 text-xs mt-1 font-medium"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="flex items-center justify-between pt-4 border-t border-slate-100 mt-4">
                        <div class="flex items-center gap-4">
                            <label class="inline-flex items-center cursor-pointer">
                                <input type="radio" name="status" value="replied" <?php echo e($ticket->status == 'replied' ? 'checked' : ''); ?> class="sr-only peer">
                                <span class="px-5 py-2 rounded-lg text-xs font-bold bg-slate-100 text-slate-500 border border-slate-200 peer-checked:bg-teal-600 peer-checked:text-white peer-checked:border-teal-600 transition-all shadow-sm">Mark as Replied</span>
                            </label>
                            <label class="inline-flex items-center cursor-pointer">
                                <input type="radio" name="status" value="resolved" <?php echo e($ticket->status == 'resolved' ? 'checked' : ''); ?> class="sr-only peer">
                                <span class="px-5 py-2 rounded-lg text-xs font-bold bg-slate-100 text-slate-500 border border-slate-200 peer-checked:bg-emerald-600 peer-checked:text-white peer-checked:border-emerald-600 transition-all shadow-sm">Resolve</span>
                            </label>
                        </div>
                        <button type="submit" class="inline-flex items-center px-8 py-3 bg-teal-600 border border-transparent rounded-lg font-bold text-sm text-white uppercase tracking-widest hover:bg-teal-700 active:bg-teal-800 transition-all duration-150 shadow-md">
                            Submit Update
                        </button>
                    </div>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH G:\All Backup  after 17-jan-26\Git-Project\Laravel\coastguard\resources\views/tickets/show.blade.php ENDPATH**/ ?>