<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 mt-2">
        <!-- System Stats Cards -->
        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 flex items-center hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-pointer border-l-4 border-l-indigo-600">
            <div class="p-4 bg-indigo-50 text-indigo-600 rounded-xl mr-4 group-hover:scale-110 transition-transform duration-300">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path>
                </svg>
            </div>
            <div>
                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Personnel</p>
                <p class="text-2xl font-black text-slate-900"><?php echo e(number_format($stats['users'])); ?></p>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 flex items-center hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-pointer border-l-4 border-l-orange-500">
            <div class="p-4 bg-orange-50 text-orange-600 rounded-xl mr-4 group-hover:scale-110 transition-transform duration-300">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path>
                </svg>
            </div>
            <div>
                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Item Master</p>
                <p class="text-2xl font-black text-slate-900"><?php echo e(number_format($stats['items'])); ?></p>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 flex items-center hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-pointer border-l-4 border-l-slate-800">
            <div class="p-4 bg-slate-50 text-slate-800 rounded-xl mr-4 group-hover:scale-110 transition-transform duration-300">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
            </div>
            <div>
                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Locations</p>
                <p class="text-2xl font-black text-slate-900"><?php echo e(number_format($stats['locations'])); ?></p>
            </div>
        </div>

        <div class="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 flex items-center hover:shadow-xl hover:-translate-y-1 transition-all duration-300 group cursor-pointer border-l-4 border-l-emerald-500">
            <div class="p-4 bg-emerald-50 text-emerald-600 rounded-xl mr-4 group-hover:scale-110 transition-transform duration-300">
                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                </svg>
            </div>
            <div>
                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Latest Item Code</p>
                <p class="text-2xl font-black text-slate-900"><?php echo e($stats['last_item']->code ?? 'N/A'); ?></p>
            </div>
        </div>
    </div>

    <!-- Notice Board Section -->
    <div class="bg-white rounded-3xl shadow-xl shadow-slate-200/50 border border-slate-100 overflow-hidden mb-8">
        <!-- Header -->
        <div class="px-8 py-5 bg-slate-900 flex items-center justify-between">
            <div class="flex items-center text-white flex-1 min-w-0">
                <div class="flex items-center">
                    <div class="p-2 bg-orange-600 rounded-lg mr-4">
                        <svg class="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-black tracking-tight text-white uppercase italic">Notice Board</h3>
                </div>

                <?php if($notices->isNotEmpty()): ?>
                    <div class="ml-10 overflow-hidden flex-1 relative h-6 hidden md:block border-l border-white/20 pl-6">
                        <div class="absolute whitespace-nowrap animate-marquee-text text-orange-400 font-bold tracking-wide text-sm flex items-center h-full">
                            <span>ATTENTION: <?php echo e($notices->first()->title); ?></span>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <div class="flex items-center space-x-4">
                <span class="text-slate-400 text-xs font-bold bg-white/5 px-4 py-2 rounded-xl border border-white/10 uppercase tracking-widest leading-none">
                    <?php echo e(now()->format('d M Y')); ?>

                </span>
            </div>
        </div>

        <!-- Notices Content -->
        <div class="px-8 py-8">
            <?php if($notices->isEmpty()): ?>
                <div class="py-20 text-center text-slate-300">
                    <svg class="w-16 h-16 mx-auto mb-4 opacity-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                    </svg>
                    <p class="italic text-lg">No active notices published yet.</p>
                </div>
            <?php else: ?>
                <div class="notice-slider overflow-y-auto h-[450px] space-y-4 pr-3 custom-scrollbar"
                    id="notice-container">
                    <?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="notice-item group bg-white rounded-xl border border-slate-100 hover:border-teal-400 hover:bg-slate-50/30 hover:shadow-lg transition-all duration-300 overflow-hidden"
                            style="margin-bottom: 10px;">
                            <!-- Notice Header -->
                            <button onclick="toggleNotice(this)"
                                class="w-full text-left focus:outline-none p-4 flex items-center gap-4">
                                <!-- Status Icon -->
                                <div class="flex-shrink-0">
                                    <?php
                                        $catColors = [
                                            'Important' => 'bg-orange-50 text-orange-600 border-orange-100',
                                            'FAQ' => 'bg-teal-50 text-teal-600 border-teal-100',
                                            'General' => 'bg-slate-50 text-slate-500 border-slate-100',
                                        ];
                                        $c = $catColors[$notice->category] ?? $catColors['General'];
                                    ?>
                                    <div
                                        class="flex h-10 w-10 items-center justify-center rounded-lg <?php echo e($c); ?> border">
                                        <svg class="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <?php if($notice->category == 'Important'): ?>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z">
                                                </path>
                                            <?php elseif($notice->category == 'FAQ'): ?>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                                                </path>
                                            <?php else: ?>
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                    d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                                                </path>
                                            <?php endif; ?>
                                        </svg>
                                    </div>
                                </div>

                                <!-- Title and Meta -->
                                <div class="flex-1 min-w-0">
                                    <div class="flex items-center gap-2 mb-1">
                                        <span
                                            class="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest border <?php echo e($c); ?>">
                                            <?php echo e($notice->category); ?>

                                        </span>
                                        <span class="text-[10px] font-medium text-slate-400 capitalize">
                                            <?php echo e($notice->published_at->format('d M — h:i A')); ?>

                                        </span>
                                        <?php if($notice->created_at->gt(now()->subDays(2))): ?>
                                            <span
                                                class="px-1.5 py-0.5 rounded bg-rose-500 text-[9px] font-bold text-white uppercase tracking-tighter">NEW</span>
                                        <?php endif; ?>
                                    </div>
                                    <h4
                                        class="text-sm font-bold text-slate-800 group-hover:text-teal-700 transition-colors duration-200">
                                        <?php echo e($notice->title); ?>

                                    </h4>
                                </div>

                                <!-- Toggle Icon -->
                                <div class="flex-shrink-0">
                                    <svg class="w-5 h-5 text-slate-300 group-hover:text-teal-500 transform transition-transform duration-300 accordion-icon"
                                        fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M19 9l-7 7-7-7"></path>
                                    </svg>
                                </div>
                            </button>

                            <!-- Notice Content -->
                            <div class="notice-content hidden bg-slate-50/50 border-t border-slate-100">
                                <div class="p-4 flex flex-col md:flex-row gap-6">
                                    <?php
                                        $extension = $notice->file_path
                                            ? pathinfo($notice->file_path, PATHINFO_EXTENSION)
                                            : '';
                                        $isImage = in_array(strtolower($extension), [
                                            'jpg',
                                            'jpeg',
                                            'png',
                                            'gif',
                                            'svg',
                                        ]);
                                    ?>

                                    <?php if($notice->file_path && $isImage): ?>
                                        <div
                                            class="w-full md:w-32 h-20 bg-white rounded border border-slate-200 flex-shrink-0 overflow-hidden">
                                            <img src="<?php echo e(asset('storage/' . $notice->file_path)); ?>"
                                                class="w-full h-full object-cover">
                                        </div>
                                    <?php endif; ?>

                                    <div class="flex-1">
                                        <p class="text-[13px] text-slate-600 leading-relaxed mb-4">
                                            <?php echo e($notice->content ?: 'No detailed content provided.'); ?>

                                        </p>

                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Slider Controls -->
                <div class="mt-6 flex items-center justify-center gap-4">
                    <button id="prevNotice"
                        class="w-10 h-10 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center text-slate-400 hover:text-teal-600 hover:border-teal-300 hover:shadow-md transition-all">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M15 19l-7-7 7-7"></path>
                        </svg>
                    </button>
                    <button id="nextNotice"
                        class="w-10 h-10 rounded-full bg-white border border-slate-200 shadow-sm flex items-center justify-center text-slate-400 hover:text-teal-600 hover:border-teal-300 hover:shadow-md transition-all">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7">
                            </path>
                        </svg>
                    </button>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <style>
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }

        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f8fafc;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #e2e8f0;
            border-radius: 10px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #cbd5e1;
        }

        @keyframes marquee-text {
            0% {
                transform: translateX(100%);
            }

            100% {
                transform: translateX(-100%);
            }
        }

        .animate-marquee-text {
            animation: marquee-text 15s linear infinite;
        }
    </style>

    <script>
        function toggleNotice(button) {
            const container = button.closest('.notice-item');
            const content = container.querySelector('.notice-content');
            const icon = button.querySelector('.accordion-icon');

            const isHidden = content.classList.contains('hidden');

            // Close others
            document.querySelectorAll('.notice-content').forEach(el => {
                if (el !== content) el.classList.add('hidden');
            });
            document.querySelectorAll('.accordion-icon').forEach(el => {
                if (el !== icon) el.classList.remove('rotate-180');
            });

            if (isHidden) {
                content.classList.remove('hidden');
                icon.classList.add('rotate-180');
            } else {
                content.classList.add('hidden');
                icon.classList.remove('rotate-180');
            }
        }

        document.addEventListener('DOMContentLoaded', function() {
            const container = document.getElementById('notice-container');
            if (!container) return;

            const nextBtn = document.getElementById('nextNotice');
            const prevBtn = document.getElementById('prevNotice');

            if (nextBtn) {
                nextBtn.addEventListener('click', () => {
                    container.scrollBy({
                        top: 150,
                        behavior: 'smooth'
                    });
                });
            }

            if (prevBtn) {
                prevBtn.addEventListener('click', () => {
                    container.scrollBy({
                        top: -150,
                        behavior: 'smooth'
                    });
                });
            }

            // Gentle Auto-scroll
            let scrollInterval = setInterval(() => {
                if (container.matches(':hover')) return;

                if (container.scrollTop + container.clientHeight >= container.scrollHeight - 5) {
                    container.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                } else {
                    container.scrollBy({
                        top: 1,
                        behavior: 'auto'
                    });
                }
            }, 60);

            // Pause on button click to avoid jumping
            [nextBtn, prevBtn].forEach(btn => {
                if (btn) btn.addEventListener('click', () => {
                    clearInterval(scrollInterval);
                    setTimeout(() => {
                        // Restart interval logic could go here if desired
                    }, 5000);
                });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH G:\All Backup  after 17-jan-26\Git-Project\Laravel\coastguard\resources\views/dashboard.blade.php ENDPATH**/ ?>