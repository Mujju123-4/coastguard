<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="max-w-7xl mx-auto">
        <div class="flex justify-between items-center mb-6">
            <div>
                <h2 class="text-2xl font-bold text-slate-800 tracking-tight">Support Tickets</h2>
                <p class="text-slate-500 text-sm mt-1">Manage and track item-related issues.</p>
            </div>
            <?php if(!auth()->user()->hasRole('Admin')): ?>
            <a href="<?php echo e(route('tickets.create')); ?>" class="inline-flex items-center px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white text-sm font-bold rounded-lg transition-all shadow-md hover:shadow-lg">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                Raise New Ticket
            </a>
            <?php endif; ?>
        </div>

        <div class="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
            <div class="p-6">
                <table id="tickets-table" class="w-full text-sm text-left">
                    <thead>
                        <tr class="text-slate-400 font-medium border-b border-slate-100">
                            <th class="pb-4 px-4 font-semibold uppercase tracking-wider text-[11px]">#</th>
                            <th class="pb-4 px-4 font-semibold uppercase tracking-wider text-[11px]">Item Code</th>
                            <th class="pb-4 px-4 font-semibold uppercase tracking-wider text-[11px]">User</th>
                            <th class="pb-4 px-4 font-semibold uppercase tracking-wider text-[11px]">Title</th>
                            <th class="pb-4 px-4 font-semibold uppercase tracking-wider text-[11px]">Status</th>
                            <th class="pb-4 px-4 font-semibold uppercase tracking-wider text-[11px]">Created At</th>
                            <th class="pb-4 px-4 font-semibold uppercase tracking-wider text-[11px]">Action</th>
                        </tr>
                    </thead>
                    <tbody class="text-slate-600 divide-y divide-slate-50">
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
    <style>
        .dataTables_wrapper .dataTables_length select {
            @apply pr-8 py-1 rounded border-slate-200 text-sm focus:ring-orange-500 focus:border-orange-500;
        }
        .dataTables_wrapper .dataTables_filter input {
            @apply px-4 py-1 rounded border-slate-200 text-sm focus:ring-orange-500 focus:border-orange-500;
        }
    </style>
    <?php $__env->stopPush(); ?>

    <?php $__env->startPush('scripts'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(function() {
            $('#tickets-table').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('tickets.index')); ?>",
                columns: [
                    {data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false},
                    {data: 'item_code', name: 'item.code'},
                    {data: 'user_name', name: 'user.name'},
                    {data: 'title', name: 'title'},
                    {data: 'status_badge', name: 'status', orderable: false, searchable: false},
                    {data: 'created_at', name: 'created_at', render: function(data){
                        return new Date(data).toLocaleDateString('en-GB', {day: '2-digit', month: 'short', year: 'numeric'});
                    }},
                    {data: 'action', name: 'action', orderable: false, searchable: false},
                ],
                language: {
                    paginate: {
                        next: '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M9 5l7 7-7 7"></path></svg>',
                        previous: '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"></path></svg>'
                    }
                }
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH G:\All Backup  after 17-jan-26\Git-Project\Laravel\coastguard\resources\views/tickets/index.blade.php ENDPATH**/ ?>